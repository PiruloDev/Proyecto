package com.example.Proyecto.model;

public class PojoDeleteEmpleado {

        private Long id;

        public PojoDeleteEmpleado() {}

        public PojoDeleteEmpleado(Long id) {
            this.id = id;
        }

        public Long getId() {
            return id;
        }
        public void setId(Long id) {
            this.id = id;
        }
    }
